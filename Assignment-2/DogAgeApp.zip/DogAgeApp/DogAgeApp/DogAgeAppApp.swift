//
//  DogAgeAppApp.swift
//  DogAgeApp
//
//  Created by Sunku Bhanu Kedhar Nath - Z1974769.
//  Created by Yaswanth Raj Varikunta - Z1973107

import SwiftUI

@main
struct DogAgeAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
