//
//  PresidentsUSAApp.swift
//  PresidentsUSA
//
//  Created by Sunku Bhanu Kedhar Nath - Z1974769.
//  Created by Yaswanth Raj Varikunta - Z1973107

import SwiftUI

@main
struct PresidentsUSAApp: App {
    var body: some Scene {
        WindowGroup {
            PresidentsListView()
        }
    }
}
